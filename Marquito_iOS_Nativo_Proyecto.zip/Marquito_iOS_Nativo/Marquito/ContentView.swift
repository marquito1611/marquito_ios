import SwiftUI

struct ContentView: View {
    @State private var tapped = false

    var body: some View {
        ZStack {
            Color(red: 0.055, green: 0.063, blue: 0.078)
                .ignoresSafeArea()

            VStack(spacing: 22) {
                ZStack {
                    RoundedRectangle(cornerRadius: 22)
                        .fill(Color(red: 0.96, green: 0.79, blue: 0.12))
                        .frame(width: 86, height: 86)
                    Text("M")
                        .font(.system(size: 52, weight: .black, design: .rounded))
                        .foregroundStyle(Color(red: 0.055, green: 0.063, blue: 0.078))
                }

                Text("Marquito")
                    .font(.largeTitle.bold())
                    .foregroundStyle(.white)

                Text("App creada por Marquito")
                    .font(.headline)
                    .foregroundStyle(.white.opacity(0.72))

                Button {
                    tapped = true
                } label: {
                    Text(tapped ? "¡Todo correcto! 🚀" : "¡Funciona!")
                        .font(.headline.bold())
                        .foregroundStyle(Color(red: 0.055, green: 0.063, blue: 0.078))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color(red: 0.96, green: 0.79, blue: 0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .padding(.top, 8)
            }
            .padding(28)
        }
        .preferredColorScheme(.dark)
    }
}
