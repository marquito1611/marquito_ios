import SwiftUI

@main
struct MarquitoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
